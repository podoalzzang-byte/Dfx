# Mechanical DXF Converter v0.2 — Android source

**Status:** Source code delivered; Android APK was **not** compiled or device-tested in this environment. This is a dimension-calibrated raster-tracing prototype **not** a certified manufacturing drawing converter.

## Implemented in v0.2

- Pick PDF/JPG/PNG/WebP from Android Documents provider (PDF **first page only**).
- Show raster preview; **tap two points** corresponding to a known dimension, then enter physical distance in millimeters. Scale is computed as `known_mm / pixel_distance`.
- Offline thresholding + thinning + connected-path tracing and polyline simplification (existing algorithm).
- Write editable DXF LWPOLYLINE objects (AC1015) with `$INSUNITS=4` (millimeters).
- Include `REVIEW_REQUIRED` red layer with a warning text. Saving requires an explicit user checkbox.
- No internet or broad storage permission.

## Build APK

1. Install Android Studio with Android SDK 35 and Java 17.
2. Open `PdfImageToDxfAndroid` project folder and allow Gradle sync.
3. Build > Build APK(s), or connect Android device and Run.
4. Alternatively upload project contents to a GitHub repository and run included GitHub Actions workflow; download built artifact.

## Workflow

1. Pick file, wait for preview.
2. Tap exact endpoints of known physical dimension (two taps); if incorrect, tap again (resets pair).
3. Enter dimension in mm; adjust black-line threshold if needed.
4. Trace; inspect result with an external CAD viewer. Check the verification checkbox and save DXF.
5. Open DXF in CAD to remove dimensions/text/false traces, rebuild arcs and true circles, close contours, and verify measured lengths against **multiple independent drawing dimensions**.

## MUST READ: manufacturing safety

The exported result is **unverified raster vectorization**. The app does not extract native PDF vectors, automatically parse printed dimensions, identify true circles/arcs, recognize threads/tolerances/GD&T, guarantee contour closure, distinguish centerlines from cutting edges, or generate verified toolpaths. Single-reference calibration cannot correct perspective/skew, distortion, or local scaling. CNC / laser / grinder / lathe operators **must independently verify** finished geometry and machining constraints using a proper CAD/CAM package. The red layer may not appear when importing entities selectively: never treat its absence as an approval.

Do not delete original technical drawings. Conversion and saving run locally; the original file is left untouched.
