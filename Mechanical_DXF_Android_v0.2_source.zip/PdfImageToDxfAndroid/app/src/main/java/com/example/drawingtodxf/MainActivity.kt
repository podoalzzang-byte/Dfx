package com.example.drawingtodxf

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val pickCode=101
    private val saveCode=102
    private var selected:Uri?=null
    private var selectedMime:String?=null
    private var result:DxfConverter.Result?=null
    private val executor=Executors.newSingleThreadExecutor()
    private lateinit var status:TextView
    private lateinit var fileLabel:TextView
    private lateinit var widthInput:EditText
    private lateinit var threshold:SeekBar
    private lateinit var convertButton:Button
    private lateinit var saveButton:Button
    private var millimetersPerPixel=0.0
    private var bitmap:android.graphics.Bitmap?=null
    private lateinit var preview:CalibrationView
    private lateinit var confirmation:CheckBox

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll=ScrollView(this)
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(42,54,42,36)
            setBackgroundColor(Color.rgb(248,250,253))
        }
        scroll.addView(root)
        fun text(s:String,size:Float,bold:Boolean=false):TextView = TextView(this).apply {
            text=s; textSize=size; setTextColor(Color.rgb(24,37,55))
            if(bold) setTypeface(null,Typeface.BOLD)
            setPadding(0,10,0,10)
        }
        fun addButton(title:String,act:()->Unit):Button = Button(this).apply {
            text=title; setOnClickListener { act() }
            root.addView(this,LinearLayout.LayoutParams(-1,-2))
        }
        root.addView(text("도면 → DXF",26f,true))
        root.addView(text("PDF · JPG · PNG 파일을 휴대폰에서 선택하고 DXF로 저장합니다. 인터넷 연결이 필요 없습니다.",14f))
        root.addView(text("1. 도면 선택",18f,true))
        fileLabel=text("아직 선택한 파일이 없습니다",14f)
        root.addView(fileLabel)
        addButton("PDF / 이미지 선택") {
            val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type="*/*"
                putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("application/pdf","image/png","image/jpeg","image/webp"))
            }
            startActivityForResult(intent,pickCode)
        }
        root.addView(text("2. 기준 치수 지정",18f,true))
        root.addView(text("파일을 선택하면 아래에 도면이 나타납니다. 실제 길이를 아는 두 점을 순서대로 터치하세요. 두 점은 같은 치수의 연장선 끝점 등 정확한 위치를 선택해야 합니다.",13f))
        preview=CalibrationView(this)
        root.addView(preview,LinearLayout.LayoutParams(-1,700))
        root.addView(text("선택한 두 점 사이 실제 길이 (mm)",13f))
        widthInput=EditText(this).apply {
            inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(""); hint="예: 50"; setSingleLine(true)
        }
        root.addView(widthInput)
        root.addView(text("흑백 인식 강도 (밝은 배경의 검정 선에 적합)",13f))
        threshold=SeekBar(this).apply {max=230;progress=170}
        root.addView(threshold)
        convertButton=addButton("3. DXF 선 추적") { startConversion() }
        confirmation=CheckBox(this).apply { text="도면 원본과 축척/형상을 확인했습니다 (검토용 DXF로 저장)";isChecked=false }
        root.addView(confirmation)
        saveButton=addButton("4. DXF 파일 저장") {
            if(result==null) {Toast.makeText(this,"먼저 변환하세요",Toast.LENGTH_SHORT).show();return@addButton}
            if(!confirmation.isChecked){status.text="먼저 검토 확인란을 체크하세요";return@addButton}
            val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type="application/octet-stream"
                putExtra(Intent.EXTRA_TITLE,"drawing_converted.dxf")
            }
            startActivityForResult(intent,saveCode)
        }
        saveButton.isEnabled=false
        status=text("준비 완료",14f)
        root.addView(status)
        root.addView(text("주의: 이미지 기반 자동 선 추적 방식입니다. PDF는 첫 페이지만 변환합니다. 문자와 정확한 치수·원호·레이어는 자동으로 복원되지 않습니다. 가공용 도면으로 사용하기 전에 반드시 CAD에서 검증하세요.",12f))
        setContentView(scroll)
    }

    @Deprecated("Uses the classic activity result API for broad Android compatibility")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK || data?.data==null)return
        val uri=data.data!!
        if(requestCode==pickCode){
            selected=uri; selectedMime=contentResolver.getType(uri);result=null;saveButton.isEnabled=false
            confirmation.isChecked=false
            fileLabel.text="선택: ${uri.lastPathSegment ?: "도면"}"
            status.text="도면을 불러오는 중..."
            executor.execute {
                val loaded=runCatching { DxfConverter.load(contentResolver,uri,selectedMime) }
                runOnUiThread {
                    loaded.onSuccess { bitmap?.recycle();bitmap=it;preview.bitmap=it;status.text="기준 치수 양 끝점을 화면에서 터치하세요." }
                        .onFailure {status.text="열기 실패: ${it.message}"}
                }
            }
        } else if(requestCode==saveCode) {
            val toWrite=result ?: return
            val scale=millimetersPerPixel
            status.text="파일 저장 중...";saveButton.isEnabled=false
            executor.execute {
                val outcome=runCatching {
                    contentResolver.openOutputStream(uri,"w")?.use { DxfConverter.writeCalibrated(toWrite,it,scale) }
                        ?: error("파일 저장을 시작할 수 없습니다")
                }
                runOnUiThread {
                    saveButton.isEnabled=true
                    status.text=if(outcome.isSuccess) "DXF 저장 완료! CAD 앱에서 확인해 주세요." else "저장 실패: ${outcome.exceptionOrNull()?.message}"
                }
            }
        }
    }
    private fun startConversion() {
        val uri=selected ?: run { status.text="도면 파일을 먼저 선택하세요";return }
        val mm=widthInput.text.toString().toDoubleOrNull()
        if(mm==null || mm<=0.0 || mm>100000.0){status.text="실제 기준 길이를 mm로 입력하세요";return}
        if(preview.points.size!=2){status.text="도면에서 기준 치수 두 점을 터치하세요";return}
        val (a,b)=preview.points
        val px=kotlin.math.hypot((a.first-b.first).toDouble(),(a.second-b.second).toDouble())
        if(px<10.0){status.text="기준 두 점의 간격이 너무 작습니다";return}
        millimetersPerPixel=mm/px
        if(!millimetersPerPixel.isFinite()){status.text="축척 계산 오류";return}
        confirmation.isChecked=false
        val level=threshold.progress.coerceIn(20,230)
        convertButton.isEnabled=false;saveButton.isEnabled=false
        status.text="선을 추적하고 있습니다. 잠시 기다려 주세요..."
        executor.execute {
            val res=runCatching {
                val source=bitmap ?: error("먼저 도면 로딩을 완료하세요")
                DxfConverter.trace(source,level)
            }
            runOnUiThread {
                convertButton.isEnabled=true
                res.onSuccess {
                    result=it
                    saveButton.isEnabled=it.paths.isNotEmpty()
                    status.text="추적된 경로 ${it.paths.size}개. 축척 ${"%.6f".format(java.util.Locale.US,millimetersPerPixel)} mm/px. 가공 전에 CAD에서 치수·원호·공차·폐곡선을 반드시 검증하세요."
                }.onFailure {status.text="변환 실패: ${it.message}"}
            }
        }
    }
    override fun onDestroy(){executor.shutdown();super.onDestroy()}
}
