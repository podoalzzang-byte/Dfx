package com.example.drawingtodxf

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.content.ContentResolver
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

/** Entirely offline bitmap -> thinned centerlines -> DXF lightweight polylines.
 * PDFs use Android PdfRenderer (first page only): this is raster tracing, NOT native vector extraction.
 */
object DxfConverter {
    data class Pt(val x: Int, val y: Int)
    data class Result(val paths: List<List<Pt>>, val width: Int, val height: Int)

    fun load(resolver: ContentResolver, uri: Uri, mime: String?): Bitmap {
        if (mime == "application/pdf" || uri.toString().lowercase().endsWith(".pdf")) {
            val fd: ParcelFileDescriptor = resolver.openFileDescriptor(uri, "r") ?: error("PDF 파일을 열 수 없습니다")
            fd.use { descriptor ->
                PdfRenderer(descriptor).use { renderer ->
                    require(renderer.pageCount > 0) { "빈 PDF입니다" }
                    renderer.openPage(0).use { page ->
                        val ratio = minOf(1600f / page.width, 1600f / page.height, 2.5f)
                        val w = max(1, (page.width * ratio).roundToInt())
                        val h = max(1, (page.height * ratio).roundToInt())
                        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        out.eraseColor(Color.WHITE)
                        page.render(out, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        return out
                    }
                }
            }
        }
        resolver.openInputStream(uri).use { input ->
            val source = BitmapFactory.decodeStream(input) ?: error("이미지를 읽을 수 없습니다")
            val factor = minOf(1f, 1600f / max(source.width, source.height))
            if (factor == 1f) return source
            val scaled = Bitmap.createScaledBitmap(source, max(1,(source.width*factor).roundToInt()), max(1,(source.height*factor).roundToInt()), true)
            source.recycle()
            return scaled
        }
    }

    fun trace(bitmap: Bitmap, threshold: Int, minLength: Int = 9): Result {
        val w = bitmap.width; val h = bitmap.height
        require(w * h <= 3_000_000) { "이미지가 너무 큽니다" }
        val pixels = IntArray(w*h)
        bitmap.getPixels(pixels,0,w,0,0,w,h)
        val fg = BooleanArray(w*h)
        for (i in pixels.indices) {
            val c = pixels[i]
            val gray = (299*Color.red(c) + 587*Color.green(c) + 114*Color.blue(c))/1000
            fg[i] = Color.alpha(c) > 64 && gray < threshold
        }
        // Zhang-Suen thinning; retain 1-pixel-wide centerlines.
        val erase = ArrayList<Int>()
        fun neigh(i:Int):BooleanArray {
            val x=i%w; val y=i/w
            if(x<=0||y<=0||x>=w-1||y>=h-1) return BooleanArray(8)
            return booleanArrayOf(fg[i-w],fg[i-w+1],fg[i+1],fg[i+w+1],fg[i+w],fg[i+w-1],fg[i-1],fg[i-w-1])
        }
        repeat(45) {
            var changed = false
            for (pass in 0..1) {
                erase.clear()
                for (y in 1 until h-1) for(x in 1 until w-1) {
                    val i=y*w+x
                    if(!fg[i]) continue
                    val p=neigh(i); val n=p.count { it }
                    if(n !in 2..6) continue
                    val transitions=(0..7).count { !p[it] && p[(it+1)%8] }
                    if(transitions!=1)continue
                    val cond= if(pass==0) (!p[0]||!p[2]||!p[4]) && (!p[2]||!p[4]||!p[6])
                              else (!p[0]||!p[2]||!p[6]) && (!p[0]||!p[4]||!p[6])
                    if(cond) erase.add(i)
                }
                if(erase.isNotEmpty()) changed=true
                erase.forEach { fg[it]=false }
            }
            if(!changed) return@repeat
        }
        val offsets=intArrayOf(-w,-w+1,1,w+1,w,w-1,-1,-w-1)
        fun neighbors(i:Int):List<Int> {
            val x=i%w; val y=i/w
            if(x==0||y==0||x==w-1||y==h-1) return emptyList()
            return offsets.map { i+it }.filter { fg[it] }
        }
        val degree=IntArray(w*h)
        for(y in 1 until h-1)for(x in 1 until w-1) {
            val i=y*w+x; if(fg[i]) degree[i]=neighbors(i).size
        }
        fun edgeKey(a:Int,b:Int):Long { val lo=minOf(a,b); val hi=maxOf(a,b); return (lo.toLong() shl 32) or (hi.toLong() and 0xffffffffL) }
        val used=HashSet<Long>()
        val paths=ArrayList<List<Pt>>()
        fun collect(start:Int,next:Int) {
            val ids=ArrayList<Int>(); ids.add(start)
            var previous=start; var current=next
            used.add(edgeKey(start,next))
            while(true) {
                ids.add(current)
                if(degree[current]!=2 || ids.size>50000) break
                val candidate=neighbors(current).firstOrNull { it!=previous && !used.contains(edgeKey(current,it)) } ?: break
                used.add(edgeKey(current,candidate))
                previous=current; current=candidate
            }
            if(ids.size<minLength) return
            val points=ids.map { Pt(it%w,it/w) }
            val simple=simplify(points,1.4)
            if(simple.size>=2) paths.add(simple)
        }
        for(i in fg.indices) if(fg[i] && degree[i] != 2) {
            for(j in neighbors(i)) if(!used.contains(edgeKey(i,j))) collect(i,j)
        }
        // closed loops (all pixels of degree 2)
        for(i in fg.indices) if(fg[i]) {
            for(j in neighbors(i)) if(!used.contains(edgeKey(i,j))) collect(i,j)
        }
        return Result(paths,w,h)
    }

    private fun simplify(p:List<Pt>, tol:Double):List<Pt> {
        if(p.size<3)return p
        val keep=BooleanArray(p.size); keep[0]=true;keep[p.lastIndex]=true
        val stack=ArrayDeque<Pair<Int,Int>>();stack.add(0 to p.lastIndex)
        while(stack.isNotEmpty()) {
            val (a,b)=stack.removeLast(); val x1=p[a].x.toDouble();val y1=p[a].y.toDouble()
            val dx=(p[b].x-x1);val dy=(p[b].y-y1);val denom=dx*dx+dy*dy
            var maxDist=tol;var idx=-1
            for(i in a+1 until b) {
                val px=p[i].x-x1;val py=p[i].y-y1
                val t=if(denom==0.0) 0.0 else ((px*dx+py*dy)/denom).coerceIn(0.0,1.0)
                val dist=hypot(px-t*dx,py-t*dy)
                if(dist>maxDist) { maxDist=dist;idx=i }
            }
            if(idx!=-1){keep[idx]=true;stack.add(a to idx);stack.add(idx to b)}
        }
        return p.filterIndexed { index,_ -> keep[index] }
    }

    fun writeCalibrated(result:Result, output:OutputStream, millimetersPerPixel:Double) {
        require(millimetersPerPixel.isFinite() && millimetersPerPixel>0) { "잘못된 축척" }
        val scale=millimetersPerPixel
        val writer=OutputStreamWriter(output, Charsets.US_ASCII).buffered()
        fun pair(code:Int, value:Any){ writer.write("$code\n$value\n") }
        fun num(v:Double)=String.format(Locale.US,"%.5f",v)
        pair(0,"SECTION");pair(2,"HEADER");pair(9,"\$ACADVER");pair(1,"AC1015");pair(9,"\$INSUNITS");pair(70,4);pair(0,"ENDSEC")
        pair(0,"SECTION");pair(2,"TABLES");pair(0,"TABLE");pair(2,"LAYER");pair(70,2)
        pair(0,"LAYER");pair(2,"TRACED");pair(70,0);pair(62,7);pair(6,"CONTINUOUS")
        pair(0,"LAYER");pair(2,"REVIEW_REQUIRED");pair(70,0);pair(62,1);pair(6,"CONTINUOUS")
        pair(0,"ENDTAB");pair(0,"ENDSEC")
        pair(0,"SECTION");pair(2,"ENTITIES")
        for(path in result.paths) {
            pair(0,"LWPOLYLINE");pair(8,"TRACED");pair(90,path.size);pair(70,0)
            for(pt in path) {pair(10,num(pt.x*scale));pair(20,num((result.height-pt.y)*scale))}
        }
        pair(0,"TEXT");pair(8,"REVIEW_REQUIRED");pair(10,"0");pair(20,num(-10.0));pair(40,"3.0")
        pair(1,"UNVERIFIED RASTER TRACE - NOT READY FOR CNC")
        pair(0,"ENDSEC");pair(0,"EOF");writer.flush()
    }
}
