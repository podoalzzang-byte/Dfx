package com.example.drawingtodxf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import android.view.MotionEvent
import kotlin.math.min

/** Displays the EXACT raster used for tracing. Two taps pick a known physical dimension. */
class CalibrationView(context: Context): View(context) {
    var bitmap: Bitmap? = null
        set(value) { field=value; points.clear(); invalidate() }
    val points = mutableListOf<Pair<Float,Float>>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onMeasure(widthMeasureSpec:Int,heightMeasureSpec:Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), 700)
    }
    private fun transform():Triple<Float,Float,Float> {
        val b=bitmap ?: return Triple(1f,0f,0f)
        val scale=min(width.toFloat()/b.width,height.toFloat()/b.height)
        return Triple(scale,(width-b.width*scale)/2f,(height-b.height*scale)/2f)
    }
    override fun onDraw(canvas:Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(225,230,237))
        val b=bitmap ?: return
        val (scale,dx,dy)=transform()
        paint.color=Color.WHITE
        canvas.drawRect(dx,dy,dx+b.width*scale,dy+b.height*scale,paint)
        canvas.save(); canvas.translate(dx,dy);canvas.scale(scale,scale)
        paint.isFilterBitmap=true; canvas.drawBitmap(b,0f,0f,paint)
        paint.color=Color.RED; paint.strokeWidth=3f/scale
        for ((x,y) in points) { canvas.drawCircle(x,y,8f/scale,paint) }
        if(points.size==2) canvas.drawLine(points[0].first,points[0].second,points[1].first,points[1].second,paint)
        canvas.restore()
    }
    override fun onTouchEvent(event:MotionEvent):Boolean {
        if(event.action!=MotionEvent.ACTION_UP) return true
        val b=bitmap ?: return true
        val (scale,dx,dy)=transform()
        val x=(event.x-dx)/scale;val y=(event.y-dy)/scale
        if(x in 0f..b.width.toFloat() && y in 0f..b.height.toFloat()) {
            if(points.size==2)points.clear()
            points.add(x to y);invalidate()
        }
        performClick();return true
    }
    override fun performClick():Boolean {super.performClick();return true}
}
